<?php
/**
 * Redirect to the summary page
 */

if ($_REQUEST['logout'] == 'true') {
  $request->getSession()->invalidate();
  header("Location: index.php");
}
else {
  require "WEB-INF/php/inc.php";

  $g_pages = load_pages();

  $g_page = $_GET['q'];

  if (! $g_pages[$g_page]) {
    $g_page = "summary";
  }

  if (! admin_init()) {
    return;
  }

  include_once($g_pages[$g_page]);

  display_footer($g_page);
}

?>
