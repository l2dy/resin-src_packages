package java.sql;

public interface RowIdLifetime {
}
