package example.data;

public interface FlickrPayload {
}
