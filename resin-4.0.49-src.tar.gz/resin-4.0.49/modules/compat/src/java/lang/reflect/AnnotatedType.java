package java.lang.reflect;

/**
 * stub for jdk-6 compilation
 */
public interface AnnotatedType {
}