<?php
$math = java_bean("math");
?>
<pre>
3 + 2 = <?= $math->add(3, 2) ?><br>
3 - 2 = <?= $math->sub(3, 2) ?><br>
3 * 2 = <?= $math->mul(3, 2) ?><br>
3 / 2 = <?= $math->div(3, 2) ?><br>
</pre>

<a href="demo.jsp">JSP demo</a>
