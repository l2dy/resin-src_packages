package java.nio.file;

public enum StandardOpenOption implements OpenOption {
  CREATE, READ, WRITE;
}