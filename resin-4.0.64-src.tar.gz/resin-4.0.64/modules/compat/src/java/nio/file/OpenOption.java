package java.nio.file;

public interface OpenOption {
}